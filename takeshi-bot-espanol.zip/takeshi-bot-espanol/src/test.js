/**
 * Archivo para ejecutar algunas pruebas,
 * nada del otro mundo.
 *
 * @author Dev Gui
 */
(async () => {})();
